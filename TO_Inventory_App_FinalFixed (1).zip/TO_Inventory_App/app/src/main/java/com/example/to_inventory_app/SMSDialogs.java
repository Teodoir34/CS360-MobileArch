package com.example.to_inventory_app;

//TEDDIE - import all necessary reqs
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

//TEDDIE - request user agreement to enable SMS
public class SMSDialogs {

    public static AlertDialog buttonToggle(final InventoryList context){

        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        builder.setTitle(R.string.sms_permission_text)
                .setCancelable(false)
                .setIcon(R.drawable.sms_notifs)
                .setMessage(R.string.sms_enab)
                .setNegativeButton(R.string.disabe_sms_butt, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts are Disabled :(", Toast.LENGTH_LONG).show();
                    InventoryList.DenySendSMS();
                    dialog.cancel();
                })
                .setPositiveButton(R.string.enab_sms_butt, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts are Enabled :)", Toast.LENGTH_LONG).show();
                    InventoryList.AllowSendSMS();
                    dialog.cancel();
                });


        return builder.create();
    }
}
