package com.example.to_inventory_app;

//TEDDIE - set public clas for entering a new item
public class EnterItem {

    int id;
    String user_email;
    String desc;
    String quantity;

    public EnterItem() {
        super();
    }

    //TEDDIE - make sure to record information for record keeping
    public EnterItem(int i, String email, String description, String quantity) {
        super();
        this.id = i;
        this.user_email = email;
        this.desc = description;
        this.quantity = quantity;
    }

    //TEDDIE - set constructors
    public EnterItem(String email, String description, String quantity) {
        this.user_email = email;
        this.desc = description;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserEmail() {
        return user_email;
    }

    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String qty) {
        this.quantity = qty;
    }
}