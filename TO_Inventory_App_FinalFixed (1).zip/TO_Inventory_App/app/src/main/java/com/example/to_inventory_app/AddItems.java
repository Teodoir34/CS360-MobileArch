package com.example.to_inventory_app;

//TEDDIE - import all necessary reqs
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.concurrent.atomic.AtomicReference;

//TEDDIE - set public class for adding items
public class AddItems extends AppCompatActivity {

    //TEDDIE - init calls
    ImageButton increaseItem, decreaseItem;
    EditText item_desc, item_count;
    Button add_button, cancel_button;
    Boolean empty_place;
    String desc_holder, count_holder, emailHolder;
    TextView employeeEmail;
    SQLiteItemDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newitem_act);

        //TEDDIE - init all necessary textViews, buttons, & editText vars
        employeeEmail = findViewById(R.id.textViewRecordedUser);
        item_desc = findViewById(R.id.editTextItemDescription);
        increaseItem = findViewById(R.id.itemQtyIncrease);
        decreaseItem = findViewById(R.id.itemQtyDecrease);
        item_count = findViewById(R.id.editTextItemQuantity);
        cancel_button = findViewById(R.id.cancelButton);
        add_button = findViewById(R.id.addButton);
        db = new SQLiteItemDBHelper(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        //TEDDIE - check inventory list with given email
        emailHolder = intent.get().getStringExtra(InventoryList.UserEmail);

        //TEDDIE - set email for record keeping
        employeeEmail.setText(getString(R.string.curr_user, emailHolder));

        //TEDDIE - set listener for increasing item
        increaseItem.setOnClickListener(view -> {
            int input = 0, total;

            String value = item_count.getText().toString().trim();

            if (!value.isEmpty()) {
                input = Integer.parseInt(value);
            }

            total = input + 1;
            item_count.setText(String.valueOf(total));
        });

        //TEDDIE - set listener for adding an item to the inventory
        add_button.setOnClickListener(view -> insertItemEntryToDB());

        //TEDDIE - set listener for canceling the item add
        cancel_button.setOnClickListener(view -> {
            //TEDDIE - set return when cancelled
            Intent add = new Intent();
            setResult(0, add);
            //TEDDIE - finish instance
            this.finish();
        });

        //TEDDIE - set listener for decreasing item
        decreaseItem.setOnClickListener(view -> {
            int input, total;

            String quantity = item_count.getText().toString().trim();

            if (quantity.equals("0")) {
                Toast.makeText(this, "Zero Quantity!", Toast.LENGTH_LONG).show();
            } else {
                input = Integer.parseInt(quantity);
                total = input - 1;
                item_count.setText(String.valueOf(total));
            }
        });

    }

    //TEDDIE - insert and sent data to Inventory DB
    public void insertItemEntryToDB() {
        String message = VerifyEditTextNotEmpty();

        if (!empty_place) {
            String email = emailHolder;
            String description = desc_holder;
            String quantity = count_holder;

            //TEDDIE - enter new item info with email attached for record keeping
            EnterItem item = new EnterItem(email, description, quantity);
            db.createItem(item);

            //TEDDIE - Display toast notification after successful add
            Toast.makeText(this,"Item Successfully Added to Inventory!", Toast.LENGTH_LONG).show();

            //TEDDIE - finish AddItem activity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            //TEDDIE - Set a message in case description field is empty - description is required!
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    //TEDDIE - Verify there is text in the edit field
    public String VerifyEditTextNotEmpty() {
        //TEDDIE - store data in holders for adding to DB
        String message = "";
        count_holder = item_count.getText().toString().trim();
        desc_holder = item_desc.getText().toString().trim();

        //TEDDIE - return message if description is empty, otherwise set to add!
        if (desc_holder.isEmpty()) {
            item_desc.requestFocus();
            empty_place = true;
            message = "An item description is required, please add one now.";
        } else {
            empty_place = false;
        }
        return message;
    }

}
