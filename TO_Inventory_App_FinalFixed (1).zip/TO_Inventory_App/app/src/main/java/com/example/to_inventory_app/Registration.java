package com.example.to_inventory_app;

//TEDDIE - import all necessary reqs
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

//TEDDIE - create class for registering a new user
public class Registration extends AppCompatActivity {

    //TEDDIE - declare buttons, db and variables
    Button registerUserButton, cancelButton;
    EditText employeeName, phone_number, employeeEmail, password;
    Boolean fieldEmpty;
    SQLiteDatabase db;
    SQLiteUserDBHelper sqlite_helper;
    String query_found = "not_found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userreg_act);

        //TEDDIE - set variables and store
        employeeEmail = findViewById(R.id.editTextEmailAddress);
        password = findViewById(R.id.editTextPassword);
        employeeName = findViewById(R.id.editTextPersonName);
        phone_number = findViewById(R.id.editTextPhoneNumber);
        cancelButton = findViewById(R.id.registerCancelButton);
        registerUserButton = findViewById(R.id.registerSignupButton);
        sqlite_helper = new SQLiteUserDBHelper(this);


        //TEDDIE - set cancel button listener
        cancelButton.setOnClickListener(view -> {
            startActivity(new Intent(Registration.this, Login.class));
            this.finish();
        });

        //TEDDIE - set register next step button listener
        registerUserButton.setOnClickListener(view -> {

            String message = noEmptyFields();
            //TEDDIE - check for email in event user already has account
            if (!fieldEmpty) {
                checkEmailInDB();
                employeeName.getText().clear();
                phone_number.getText().clear();
                employeeEmail.getText().clear();
                password.getText().clear();
            } else {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });


    }

    //TEDDIE - register user as part of C(RUD)
    public void createUserinDB(){

        //TEDDIE - save user info entered into required fields
        String phone = phone_number.getText().toString().trim();
        String email = this.employeeEmail.getText().toString().trim();
        String name = employeeName.getText().toString().trim();
        String pass = password.getText().toString().trim();
        Users user = new Users(name, phone, email, pass);
        sqlite_helper.createUser(user);

        //TEDDIE - success woop!
        Toast.makeText(Registration.this,"Successfully Registered! Welcome!", Toast.LENGTH_LONG).show();

        //TEDDIE -  now log in
        startActivity(new Intent(Registration.this, Login.class));
        this.finish();
    }

    //TEDDIE - empty field check, must have info to successfully register
    public String noEmptyFields() {
        String message = "";
        String name = employeeName.getText().toString().trim();
        String phone = phone_number.getText().toString().trim();
        String email = this.employeeEmail.getText().toString().trim();
        String pass = password.getText().toString().trim();

        if (name.isEmpty()) {
            employeeName.requestFocus();
            fieldEmpty = true;
            message = "Name is required";
        } else if (phone.isEmpty()){
            phone_number.requestFocus();
            fieldEmpty = true;
            message = "Phone number is required";
        } else if (email.isEmpty()){
            this.employeeEmail.requestFocus();
            fieldEmpty = true;
            message = "Work email is required";
        } else if (pass.isEmpty()){
            password.requestFocus();
            fieldEmpty = true;
            message = "Password is required";
        } else {
            fieldEmpty = false;
        }
        return message;
    }

    //TEDDIE -  verify email is new
    public void checkEmailInDB(){

        db = sqlite_helper.getWritableDatabase();
        String email = this.employeeEmail.getText().toString().trim();
        Cursor cursor = db.query(SQLiteUserDBHelper.USERS_TABLE_NAME, null, " " + SQLiteUserDBHelper.COL3_email + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // set result if found and close cursor
                query_found = "Email Found";
                cursor.close();
            }
        }
        sqlite_helper.close();

        //TEDDIE - if email is already registered, request user to go hit forgot password instead
        if(query_found.equalsIgnoreCase("Email Found - please select forgot password!"))
        {
            Toast.makeText(Registration.this, "Email Found - please select forgot password!",Toast.LENGTH_LONG).show();
        }
        else {
            createUserinDB();
        }
        query_found = "not_found" ;
    }

}
