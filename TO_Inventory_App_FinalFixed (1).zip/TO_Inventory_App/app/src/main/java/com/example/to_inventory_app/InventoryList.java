package com.example.to_inventory_app;

//TEDDIE - import all necessary reqs
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;

//TEDDIE - set public class for inventory list
public class InventoryList extends AppCompatActivity {

    //TEDDIE - set button declarations and display items in ListView
    TextView user_name, item_total_count;
    ListView ItemsListView;
    ImageButton add_button, sms_button;
    SQLiteItemDBHelper db;
    static String userHolder, emailHolder, PhoneNumHolder;
    AlertDialog AlertDialog = null;
    ArrayList<EnterItem> all_items;
    int itemsCount;
    ItemRows itemRows;

    private static boolean smsApproved = false;
    private static boolean deleteItems = false;
    public static final String UserEmail = "";
    private static final int sms_request_perms = 0;


    //TEDDIE - put sign out button on top for easy access
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.app_menu_top, menu);
        return true;
    }

    //TEDDIE - exit and log out when hitting exit button
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.exitApp) {
            db.close();
            super.finish();
            Toast.makeText(this,"You've been logged out.", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    //TEDDIE - handle activity adjustments
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                itemsCount = db.getItemsCount();
                item_total_count.setText(String.valueOf(itemsCount));
                if(itemRows == null)	{
                    itemRows = new ItemRows(this, all_items, db);
                    ItemsListView.setAdapter(itemRows);
                }

                //TEDDIE - retrieve all items and refresh view
                itemRows.items = (ArrayList<EnterItem>) db.getAllItems();
                ((BaseAdapter)ItemsListView.getAdapter()).notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show();
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.itemlist_act);

        //TEDDIE - init variables
        db = new SQLiteItemDBHelper(this);
        add_button = findViewById(R.id.addButton);
        sms_button = findViewById(R.id.smsNotif);
        user_name = findViewById(R.id.textViewNameLabel);
        item_total_count = findViewById(R.id.textViewTotalItemsCount);
        ItemsListView = findViewById(R.id.bodyListView);

        //TEDDIE - create bundle for log in activity
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            userHolder = bundle.getString("employee_name");
            emailHolder = bundle.getString("emp_email");
            PhoneNumHolder = bundle.getString("user_phone");
            //TEDDIE - create welcome message to confirm user name and successful log in
            user_name.setText( getString(R.string.howdy, userHolder.toUpperCase()));
        }

        //TEDDIE - get list of all inventory items
        all_items = (ArrayList<EnterItem>) db.getAllItems();
        itemsCount = db.getItemsCount();

        //TEDDIE - if there aren't no items them display
        if (itemsCount > 0) {
            itemRows = new ItemRows(this, all_items, db);
            ItemsListView.setAdapter(itemRows);
        //TEDDIE - else share empty db notification
        } else {
            Toast.makeText(this, "There is no inventory currently!!!", Toast.LENGTH_LONG).show();
        }

        item_total_count.setText(String.valueOf(itemsCount));

        //TEDDIE - set add item listener
        add_button.setOnClickListener(view -> {
            Intent add = new Intent(this, AddItems.class);
            add.putExtra(UserEmail, emailHolder);
            startActivityForResult(add, 1);
        });

        //TEDDIE - set sms button listener
        sms_button.setOnClickListener(view -> {
            //TEDDIE - ask for permission
            //TEDDIE - if granter share permissions
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"SMS Permissions Need Approval", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            sms_request_perms);
                }
            } else {
                Toast.makeText(this,"SMS has been enabled!", Toast.LENGTH_LONG).show();
            }
            // Open SMS Alert Dialog
            AlertDialog = SMSDialogs.buttonToggle(this);
            AlertDialog.show();
        });

    }


    //TEDDIE - grab user response and record
    public static void AllowSendSMS() {
        smsApproved = true;
    }

    public static void DenySendSMS() {
        smsApproved = false;
    }

    //TEDDIE - set SMS notification message to user phone number
    public static void SendSMSMessage(Context context) {
        String phone_number = PhoneNumHolder;
        String sms_msg = "An item in the inventory list is now out of stock!!";

        //TEDDIE - permissions alert
        if (smsApproved) {
            try {
                SmsManager sms_manager = SmsManager.getDefault();
                sms_manager.sendTextMessage(phone_number, null, sms_msg, null, null);
                Toast.makeText(context, "SMS successfully sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Permission has been Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "SMS Notifications have been disabled :(", Toast.LENGTH_LONG).show();
        }
    }
}