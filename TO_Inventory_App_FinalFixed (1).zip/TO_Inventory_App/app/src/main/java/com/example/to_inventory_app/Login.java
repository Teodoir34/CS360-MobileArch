package com.example.to_inventory_app;

//TEDDIE - import all necessary reqs
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

//TEDDIE - set login class
public class Login extends AppCompatActivity {


    //TEDDIE - set forgot password pop up and textEdit boxes
    Boolean empty_place;
    PopupWindow forgotPopup;
    EditText email, password;

    //TEDDIE - iset temp pass for user entry
    String temporary_password_entered = "EMPTY_PASS" ;

    //TEDDIE - declare variables, buttons, activity, and DB references
    SQLiteDatabase db;
    SQLiteUserDBHelper sqliteDBHelper;
    String name_place, phone_number_place, email_place, pass_place;
    Button login_button, register_button, forgot_pass_button;
    Activity activity;


    //TEDDIE - start log in check
    @Override
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);

        //TEDDIE - set default loading as log in
        setContentView(R.layout.login_act);
        activity = this;

        //TEDDIE - further declare variables for load instance
        login_button = findViewById(R.id.signinButton);
        register_button = findViewById(R.id.registerButton);
        forgot_pass_button = findViewById(R.id.forgotPasswordButton);
        email = findViewById(R.id.editTextEmailAddress);
        password = findViewById(R.id.editTextPassword);

        //TEDDIE - set handler ref
        sqliteDBHelper = new SQLiteUserDBHelper(this);


        //TEDDIE - set listener for register button
        register_button.setOnClickListener(view -> {
            Intent intent = new Intent(Login.this, Registration.class);
            startActivity(intent);
        });

        //TEDDIE - set listener for login button
        login_button.setOnClickListener(view -> {
            UserLogin();
        });


        //TEDDIE - set listener for forgot pass button
        forgot_pass_button.setOnClickListener(view -> {

            email_place = email.getText().toString().trim();
            if (!email_place.isEmpty()) {
                forgottenPassword();
            } else {
                Toast.makeText(Login.this, "Please enter your work email to continue.", Toast.LENGTH_LONG).show();
            }
        });
    }

    //TEDDIE - set login function
    public void UserLogin() {
        String message = checkEditTextFieldEmpty();

        if(!empty_place) {
            db = sqliteDBHelper.getWritableDatabase();

            Cursor cursor = db.query(SQLiteUserDBHelper.USERS_TABLE_NAME, null, " " + SQLiteUserDBHelper.COL3_email + "=?", new String[]{email_place}, null, null, null);

            //TEDDIE - iterate cursor for storing name and passwords
            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    temporary_password_entered = cursor.getString(cursor.getColumnIndex(SQLiteUserDBHelper.COL4_pass));
                    name_place = cursor.getString(cursor.getColumnIndex(SQLiteUserDBHelper.COL1_name));
                    phone_number_place = cursor.getString(cursor.getColumnIndex(SQLiteUserDBHelper.COL2_number));

                    cursor.close();
                }
            }
            sqliteDBHelper.close();

            //TEDDIE - verify password for authentication and record keeping
            checkPassMatches();
        } else {
            Toast.makeText(Login.this, message, Toast.LENGTH_LONG).show();
        }
    }

    //TEDDIE - set return message for empty text fields
    public String checkEditTextFieldEmpty() {
        String textFieldMessage = "";
        email_place = email.getText().toString().trim();
        pass_place = password.getText().toString().trim();

        if (email_place.isEmpty()){
            email.requestFocus();
            empty_place = true;
            textFieldMessage = "Please put in your work email to continue.";
        } else if (pass_place.isEmpty()){
            password.requestFocus();
            empty_place = true;
            textFieldMessage = "Please put in your password to continue.";
        } else {
            empty_place = false;
        }
        return textFieldMessage;
    }

    //TEDDIE - clear fields for repeat authentication upon log out
    public void clearEditText() {
        email.getText().clear();
        password.getText().clear();
    }


    //TEDDIE - set forgot pass function
    public void forgottenPassword() {


        LayoutInflater inflater = activity.getLayoutInflater();
        View layout = inflater.inflate(R.layout.forgotpass_act, activity.findViewById(R.id.popup_element));

        //TEDDIE - use phone to verify user prior to sharing password
        EditText phone_number = layout.findViewById(R.id.editTextItemDescriptionPopup);
        TextView password = layout.findViewById(R.id.textViewPassword);

        forgotPopup = new PopupWindow(layout, 800, 800, true);
        forgotPopup.showAtLocation(layout, Gravity.CENTER, 0, 0);
        db = sqliteDBHelper.getWritableDatabase();
        Cursor cursor = db.query(SQLiteUserDBHelper.USERS_TABLE_NAME, null, " " + SQLiteUserDBHelper.COL3_email + "=?", new String[]{email_place}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                phone_number_place = cursor.getString(cursor.getColumnIndex(SQLiteUserDBHelper.COL2_number));
                temporary_password_entered = cursor.getString(cursor.getColumnIndex(SQLiteUserDBHelper.COL4_pass));
                cursor.close();
            }
        }
        sqliteDBHelper.close();

        //TEDDIE - set button declarations
        Button cancel_button = layout.findViewById(R.id.forgotCancelButton);
        Button get_pass_button = layout.findViewById(R.id.forgotGetButton);

        //TEDDIE - set button cancel for pop up
        cancel_button.setOnClickListener(view -> {
            Toast.makeText(activity, "Cancelled request", Toast.LENGTH_SHORT).show();
            forgotPopup.dismiss();
        });

        //TEDDIE - check phone number
        get_pass_button.setOnClickListener(view -> {
            String verifyPhone = phone_number.getText().toString();

            if(verifyPhone.equals(phone_number_place)) {
                password.setText(temporary_password_entered);

                new android.os.Handler().postDelayed(() -> forgotPopup.dismiss(), 1500);
            } else {
                //TEDDIE - return error if phone number doesn't match user email address
                Toast.makeText(activity, "Phone number does not match work email", Toast.LENGTH_LONG).show();
            }
        });

    }

    //TEDDIE - check pass to email
    public void checkPassMatches(){

        //TEDDIE - log in success!
        if(temporary_password_entered.equalsIgnoreCase(pass_place)) {

            Toast.makeText(Login.this,"Logged In!",Toast.LENGTH_SHORT).show();

            //TEDDIE - log in recording
            Bundle bundle = new Bundle();
            bundle.putString("employee_name", name_place);
            bundle.putString("emp_email", email_place);
            bundle.putString("user_phone", phone_number_place);
            Intent intent = new Intent(Login.this, InventoryList.class);
            intent.putExtras(bundle);
            startActivity(intent);
            clearEditText();
        } else {
            //TEDDIE - Log in failed
            Toast.makeText(Login.this,"Login Failed :(\nIncorrect password or email!r",Toast.LENGTH_LONG).show();
        }
        temporary_password_entered = "NOT_FOUND" ;
    }
}