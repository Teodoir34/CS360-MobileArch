package com.example.to_inventory_app;

//TEDDIE - create class for user information to ensure record keeping
public class Users {

    //TEDDIE - declare variables
    int id;
    String first_name;
    String phone_num;
    String work_email;
    String unique_pass;

    public Users() {
        super();
    }

    //TEDDIE - set id automatically as needed
    public Users(int i, String name, String phone, String email, String password) {
        super();
        this.id = i;
        this.first_name = name;
        this.phone_num = phone;
        this.work_email = email;
        this.unique_pass = password;
    }

    public Users(String name, String phone, String email, String password) {
        this.first_name = name;
        this.phone_num = phone;
        this.work_email = email;
        this.unique_pass = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return first_name;
    }

    public void setUserName(String name) {
        this.first_name = name;
    }

    public String getUserPhone() {
        return phone_num;
    }

    public void setUserPhone(String phone) {
        this.phone_num = phone;
    }

    public String getUserEmail() {
        return work_email;
    }

    public void setUserEmail(String email) {
        this.work_email = email;
    }

    public String getUserPass() {
        return unique_pass;
    }

    public void setUserPass(String pass) {
        this.unique_pass = pass;
    }
}