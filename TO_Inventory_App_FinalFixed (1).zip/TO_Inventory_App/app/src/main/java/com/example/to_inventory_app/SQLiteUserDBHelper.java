package com.example.to_inventory_app;

//TEDDIE - import all necessary reqs
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//TEDDIE - set SQL DB for User DB
public class SQLiteUserDBHelper extends SQLiteOpenHelper {

    //TEDDIE - set table and data information
    private static final String DB_name = "UserData.DB";
    public static final String USERS_TABLE_NAME = "UserInformation";
    private static final int DB_version = 1;
    public static final String COL0_id = "id";
    public static final String COL1_name = "name";
    public static final String COL2_number = "phone_number";
    public static final String COL3_email = "email";
    public static final String COL4_pass = "password";

    private static final String CREATE_USERS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            USERS_TABLE_NAME + " (" +
            COL0_id + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COL1_name + " VARCHAR, " +
            COL2_number + " VARCHAR, " +
            COL3_email + " VARCHAR, " +
            COL4_pass + " VARCHAR" + ");";

    public SQLiteUserDBHelper(Context context) {
        super(context, DB_name, null, DB_version);
    }

    //TEDDIE - initiaite table creation
    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE_NAME);
        onCreate(db);
    }

    //TEDDIE - CREATE (CRUD)
    public void createUser(Users user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL1_name, user.getUserName());
        values.put(COL2_number, user.getUserPhone());
        values.put(COL3_email, user.getUserEmail());
        values.put(COL4_pass, user.getUserPass());

        db.insert(USERS_TABLE_NAME, null, values);
        db.close();
    }


}